package com.dangdangs.pet.service;

import com.dangdangs.pet.vo.PetVO;

public interface PetService {
	
	public void insertPet(PetVO petVO);
}
